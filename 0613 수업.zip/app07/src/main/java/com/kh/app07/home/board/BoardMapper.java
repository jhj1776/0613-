package com.kh.app07.home.board;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {



}
